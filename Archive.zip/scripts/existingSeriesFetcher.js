/**
 * Fetches the user's series from an AudiobookShelf server and extracts ASIN data.
 * This replicates the behavior of the original PHP version entirely in the browser.
 *
 * @param {string} serverUrl - Base URL of the AudiobookShelf server (no trailing slash).
 * @param {string} username - AudiobookShelf username.
 * @param {string} password - AudiobookShelf password.
 * @returns {Promise<{ status: string, seriesFirstASIN: object[], seriesAllASIN: object[] }>}
 */
export async function fetchUserSeriesData(serverUrl, username, password) {
  if (!serverUrl || !username || !password) {
    throw new Error("Missing required fields: URL, username, or password.");
  }

  const cleanedUrl = serverUrl.replace(/\/+$/, "");
  const loginEndpoint = `${cleanedUrl}/login`;

  // Step 1: Authenticate with AudiobookShelf API
  const loginResponse = await fetch(loginEndpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: username.trim(),
      password: password.trim(),
    }),
  });

  if (!loginResponse.ok) {
    const errorText = await loginResponse.text();
    throw new Error(`Login failed: ${errorText}`);
  }

  const loginData = await loginResponse.json();
  const token = loginData?.user?.token;
  const libraryId = loginData?.userDefaultLibraryId;

  if (!token || !libraryId) {
    throw new Error("Login succeeded but missing token or library ID.");
  }

  // Step 2: Fetch all series using pagination
  const seriesFirstASIN = [];
  const seriesAllASIN = [];

  const limit = 20;
  let page = 0;
  let totalSeriesCount = null;

  do {
    const seriesUrl = `${cleanedUrl}/api/libraries/${libraryId}/series?limit=${limit}&page=${page}`;
    const seriesResponse = await fetch(seriesUrl, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
        "User-Agent": "AudibleMetaBot/1.0 (+https://github.com/xFrieDSpuDx/completeseries)",
      },
    });

    if (!seriesResponse.ok) {
      const errorText = await seriesResponse.text();
      throw new Error(`Failed to fetch series (page ${page}): ${errorText}`);
    }

    const seriesData = await seriesResponse.json();
    const seriesList = seriesData?.results || [];

    if (totalSeriesCount === null && typeof seriesData.total === "number") {
      totalSeriesCount = seriesData.total;
    }

    for (const series of seriesList) {
      const seriesName = series.name || "Unknown Series";
      const books = series.books || [];

      // First ASIN per series
      if (books.length > 0) {
        const firstBookMeta = books[0]?.media?.metadata || {};
        seriesFirstASIN.push({
          series: seriesName,
          title: firstBookMeta.title || "Unknown Title",
          asin: firstBookMeta.asin || "Unknown ASIN",
        });
      }

      // All ASINs per series
      for (const book of books) {
        const bookMeta = book?.media?.metadata || {};
        seriesAllASIN.push({
          series: seriesName,
          title: bookMeta.title || "Unknown Title",
          asin: bookMeta.asin || "Unknown ASIN",
        });
      }
    }

    page++;
  } while (seriesFirstASIN.length < totalSeriesCount);

  // Step 3: Return result
  return {
    status: "success",
    seriesFirstASIN,
    seriesAllASIN,
  };
}
